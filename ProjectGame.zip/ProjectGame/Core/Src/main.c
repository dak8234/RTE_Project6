/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2020 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>

#include "stm32l476g_discovery.h"
#include "stm32l476g_discovery_gyroscope.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define UART_BUFFER_SIZE (80)
#define LEVEL_TIME_MAX 100
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

RNG_HandleTypeDef hrng;

SPI_HandleTypeDef hspi2;

TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart2;

/* USER CODE BEGIN PV */
float gbl_buffer[3] = {0};

uint8_t gbl_uart2_transmitBuffer[UART_BUFFER_SIZE];
uint8_t gbl_uart2_receiveBuffer[UART_BUFFER_SIZE];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_I2C2_Init(void);
static void MX_RNG_Init(void);
static void MX_SPI2_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */
void updateBoard(int x, int y, int targetX, int targetY, int init);
void updateLevel(int Level, int totalScore, int stageScore);
void updateStage(int stageCnt, int hit);
void updateFinal(int maxLevel, int score[6]);
uint16_t hw_random(uint16_t max, uint16_t min);
void randomPos(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
int gameClock;
int randomX[6] = {0,0,0,0,0,0};
int randomY[6] = {0,0,0,0,0,0};
//int prevX;
//int prevY;
int ASCII_ESC = 27;
int prevX[4] = {0,0,0,0};
int prevY[4] = {0,0,0,0};
int moveCNT;

int gameTimeList[6] = {100,66,44,30,20,13};

void updateBoard(int x, int y, int targetX, int targetY, int init){
	if(init){
		moveCNT = 0;
		prevX[0] = x;
		prevY[0] = y;
		sprintf((char*)gbl_uart2_transmitBuffer,"%c[2J\r", ASCII_ESC);
		HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
		for(int i = 0; i < 22; i++){
			for(int j = 0; j < 42; j++){
				if(j == 0 || j == 41){
					sprintf((char*)gbl_uart2_transmitBuffer,"|");
					HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
				}
				else if(i == 0 || i == 21){
					sprintf((char*)gbl_uart2_transmitBuffer,"-");
					HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
				}
				else{
					sprintf((char*)gbl_uart2_transmitBuffer," ");
					HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
				}
			}
			if(i!=21){
				sprintf((char*)gbl_uart2_transmitBuffer,"\n\r");
				HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			}
		}

	}
	else{
		if(moveCNT == 1){
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bO", ASCII_ESC, prevY[0] + 2, prevX[0] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			prevX[1] = prevX[0];
			prevX[0] = x;
			prevY[1] = prevY[0];
			prevY[0] = y;
		}
		else if(moveCNT == 2){
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bO", ASCII_ESC, prevY[0] + 2, prevX[0] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bo", ASCII_ESC, prevY[1] + 2, prevX[1] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			prevX[2] = prevX[1];
			prevX[1] = prevX[0];
			prevX[0] = x;
			prevY[2] = prevY[1];
			prevY[1] = prevY[0];
			prevY[0] = y;
		}
		else if(moveCNT == 3){
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bO", ASCII_ESC, prevY[0] + 2, prevX[0] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bo", ASCII_ESC, prevY[1] + 2, prevX[1] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\b.", ASCII_ESC, prevY[2] + 2, prevX[2] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			prevX[3] = prevX[2];
			prevX[2] = prevX[1];
			prevX[1] = prevX[0];
			prevX[0] = x;
			prevY[3] = prevY[2];
			prevY[2] = prevY[1];
			prevY[1] = prevY[0];
			prevY[0] = y;
		}
		else{
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bO", ASCII_ESC, prevY[0] + 2, prevX[0] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\bo", ASCII_ESC, prevY[1] + 2, prevX[1] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\b.", ASCII_ESC, prevY[2] + 2, prevX[2] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\b ", ASCII_ESC, prevY[3] + 2, prevX[3] + 3);
			HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
			prevX[3] = prevX[2];
			prevX[2] = prevX[1];
			prevX[1] = prevX[0];
			prevX[0] = x;
			prevY[3] = prevY[2];
			prevY[2] = prevY[1];
			prevY[1] = prevY[0];
			prevY[0] = y;
		}

	}//
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\b⛋", ASCII_ESC, targetY + 2, targetX + 3);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH\b□", ASCII_ESC, y + 2, x + 3);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	moveCNT ++;
}

void updateLevel(int level, int totalScore, int levelScore){
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[2J", ASCII_ESC);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHLEVEL  %d", ASCII_ESC, 9, 15, level);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);

	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHScore:", ASCII_ESC, 11, 15);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dH%d", ASCII_ESC, 12, 15, totalScore);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
}

void updateStage(int stageCnt, int hit){
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[2J", ASCII_ESC);
	if(hit){
		HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
		sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHSuccess!", ASCII_ESC, 7, 15);
	}
	else{
		HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
		sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHFailed Hit!", ASCII_ESC, 7, 15);
	}
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHBegin Stage: %d", ASCII_ESC, 9, 15, stageCnt + 1);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
}

void updateFinal(int maxLevel, int score[6]){
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[2J", ASCII_ESC);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHCongrats!", ASCII_ESC, 7, 15);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHMAX LEVEL  %d", ASCII_ESC, 9, 15, maxLevel);
	HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);

	for(int i = 0; i < maxLevel; i++){
		sprintf((char*)gbl_uart2_transmitBuffer,"%c[%d;%dHLevel %d Score: %d", ASCII_ESC, 10+i, 15, i+1, score[i]);
		HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
	}
}

uint16_t hw_random(uint16_t max, uint16_t min) {
	uint32_t raw;
	while(HAL_RNG_GenerateRandomNumber(&hrng, &raw) != HAL_OK) {};
	return (uint16_t)((raw)%(max-min+1) + min);
}

void randomPos(){
	int randx = 0;
	int randy = 0;

	randomX[0] = hw_random(39,0);
	randomY[0] = hw_random(19,0);

	for(int i = 1; i<6; i++){
		randx = hw_random(39,0);
		while(abs(randomX[i-1] - randx) < 10){
			randx = hw_random(39, 0);
		}
		randomX[i] = randx;
		randomY[i] = hw_random(19,0);
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_I2C2_Init();
  MX_RNG_Init();
  MX_SPI2_Init();
  MX_USART2_UART_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */
  gameClock = 0;
  int prevClock = 0;
  int currentX = 19; //board width is 40 (0-39) so middle is 19
  int currentY = 9; //board depth is 20 (0-19) so middle is 9
  int tempX = 0;
  int tempY = 0;

  int targetX = 0;
  int targetY = 0;

  int currentLevel = 1;
  int totalScore = 0;
  int lvlScore[6] = {0,0,0,0,0,0};
  int delayCNT = 0;

  int newGameFlg = 1;
  int runGameFlg = 1;
  int posChange = 0; //if not 1 pos has changed and update needed

  int hitFlg = 0;
  int stageCnt = 0;
  int levelScore = 0;

  int gameTime = LEVEL_TIME_MAX;


  for (unsigned char i = 0; i < UART_BUFFER_SIZE; i++)  {
         gbl_uart2_transmitBuffer[i] = '0' + i;
         gbl_uart2_receiveBuffer[i] = 0;
      }

  sprintf((char*)gbl_uart2_transmitBuffer,"\n\n\n\n\r");
  HAL_UART_Transmit(&huart2, gbl_uart2_transmitBuffer, strlen((char *)gbl_uart2_transmitBuffer),100);
  if(BSP_GYRO_Init() != HAL_OK)  {
  		    /* Initialization Error */
  		    Error_Handler();
  	  }
  updateLevel(currentLevel, totalScore, lvlScore[currentLevel-1]);
  delayCNT = 40;
  while(delayCNT){
	  if(prevClock != gameClock){
		  prevClock = gameClock;
		  delayCNT --;
	  }
  }
  delayCNT = 0;
  randomPos();
//  targetX = randomX[0];
//  targetY = randomY[0];
  while(runGameFlg){
	  if(prevClock != gameClock){
		  prevClock = gameClock;
		  if(delayCNT <= 0){
			  if(newGameFlg){
				  updateBoard(currentX,currentY,targetX,targetY, 1);
				  newGameFlg = 0;
				  gameClock = 0;
				  prevClock = gameClock;
				  targetX = randomX[stageCnt];
				  targetY = randomY[stageCnt];
				  currentX = 19;
				  currentY = 9;
				  hitFlg = 0;
			  }
			  delayCNT = 0;
			  BSP_GYRO_GetXYZ(gbl_buffer);
			  tempX = (int32_t)( gbl_buffer[0]*0.070f);
			  tempY = (int32_t)( gbl_buffer[1]*0.070f);
			  if(tempX < -500){
				  currentX--;
				  if(currentX < 0) currentX = 0;
				  posChange = 1;
			  }
			  else if(tempX > 500){
				  currentX++;
				  if(currentX > 39) currentX = 39;
				  posChange = 1;
			  }

			  if(tempY < -200){
				  currentY--;
				  if(currentY < 0) currentY = 0;
				  posChange = 1;
			  }
			  else if(tempY > 300){
				  currentY++;
				  if(currentY > 19) currentY = 19;
				  posChange = 1;
			  }
			  if(posChange) updateBoard(currentX, currentY, targetX, targetY, 0);
			  if((targetY + 1 >= currentY) && (targetY - 1 <= currentY) && (targetX + 1 >= currentX) && (targetX - 1 <= currentX)){
				hitFlg = 1;
			  }
			  else hitFlg = 0;

			  if((gameClock >= gameTime)){
			  //update score
				  stageCnt ++;
				  if(hitFlg == 1){
					  totalScore += 500;
					  levelScore += 500;
				  }
				  if(stageCnt > 5){ //update to new level
					  stageCnt = 0;
					  lvlScore[currentLevel - 1] = levelScore;
					  //currentLevel ++;

					  if(currentLevel >= 6 || levelScore == 0){ //check if game is over
					  	if(currentLevel > 6) currentLevel = 6;
					  	updateFinal(currentLevel, lvlScore);
					  	runGameFlg = 0;
					  }
					  else{ //game isn't over, proceed to next level and generate new random targets
						  updateLevel(currentLevel, totalScore, lvlScore[currentLevel - 1]);
						  delayCNT = 40;
						  gameTime = gameTimeList[currentLevel - 1];
						  randomPos();
						  levelScore = 0;
						  currentLevel ++;
					  }
				  }
				  else{//restart to next stage on same level
					  updateStage(stageCnt, hitFlg);
					  delayCNT = 5;
				  }
				  //stageScore[currentLevel - 1] = 500;
				  //totalScore += stageScore[currentLevel - 1];
				  newGameFlg = 1;


			  }
//			  else if(gameClock > gameTime){
//				  updateFinal(currentLevel, stageScore);
//				  runGameFlg = 0;
//			  }
		  }
		  else delayCNT--;
	  }
  }
	/* Init the uart Buffers */

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Configure LSE Drive Capability 
  */
  HAL_PWR_EnableBkUpAccess();
  __HAL_RCC_LSEDRIVE_CONFIG(RCC_LSEDRIVE_LOW);
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSE|RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.LSEState = RCC_LSE_ON;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB busses clocks 
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_I2C1
                              |RCC_PERIPHCLK_I2C2|RCC_PERIPHCLK_RNG;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c2ClockSelection = RCC_I2C2CLKSOURCE_PCLK1;
  PeriphClkInit.RngClockSelection = RCC_RNGCLKSOURCE_PLLSAI1;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 16;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage 
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Enable MSI Auto calibration 
  */
  HAL_RCCEx_EnableMSIPLLMode();
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.Timing = 0x10909CEC;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter 
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter 
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief I2C2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C2_Init(void)
{

  /* USER CODE BEGIN I2C2_Init 0 */

  /* USER CODE END I2C2_Init 0 */

  /* USER CODE BEGIN I2C2_Init 1 */

  /* USER CODE END I2C2_Init 1 */
  hi2c2.Instance = I2C2;
  hi2c2.Init.Timing = 0x10909CEC;
  hi2c2.Init.OwnAddress1 = 0;
  hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c2.Init.OwnAddress2 = 0;
  hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
  hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c2) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Analogue filter 
  */
  if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure Digital filter 
  */
  if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C2_Init 2 */

  /* USER CODE END I2C2_Init 2 */

}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief SPI2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI2_Init(void)
{

  /* USER CODE BEGIN SPI2_Init 0 */

  /* USER CODE END SPI2_Init 0 */

  /* USER CODE BEGIN SPI2_Init 1 */

  /* USER CODE END SPI2_Init 1 */
  /* SPI2 parameter configuration*/
  hspi2.Instance = SPI2;
  hspi2.Init.Mode = SPI_MODE_MASTER;
  hspi2.Init.Direction = SPI_DIRECTION_2LINES;
  hspi2.Init.DataSize = SPI_DATASIZE_4BIT;
  hspi2.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi2.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi2.Init.NSS = SPI_NSS_SOFT;
  hspi2.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_2;
  hspi2.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi2.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi2.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi2.Init.CRCPolynomial = 7;
  hspi2.Init.CRCLength = SPI_CRC_LENGTH_DATASIZE;
  hspi2.Init.NSSPMode = SPI_NSS_PULSE_ENABLE;
  if (HAL_SPI_Init(&hspi2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI2_Init 2 */

  /* USER CODE END SPI2_Init 2 */

}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */
	__HAL_RCC_TIM2_CLK_ENABLE();
  /* USER CODE END TIM2_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 7999;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 1000;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim2, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */
  HAL_TIM_Base_Start_IT(&htim2);
  /* USER CODE END TIM2_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOE_CLK_ENABLE();
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOE, AUDIO_RST_Pin|LD_G_Pin|XL_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, LD_R_Pin|M3V3_REG_ON_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OTG_FS_PowerSwitchOn_GPIO_Port, OTG_FS_PowerSwitchOn_Pin, GPIO_PIN_SET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(OTG_FS_VBUS_GPIO_Port, OTG_FS_VBUS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GYRO_CS_GPIO_Port, GYRO_CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : SAI1_MCK_Pin SAI1_FS_Pin SAI1_SCK_Pin SAI1_SD_Pin 
                           AUDIO_DIN_Pin */
  GPIO_InitStruct.Pin = SAI1_MCK_Pin|SAI1_FS_Pin|SAI1_SCK_Pin|SAI1_SD_Pin 
                          |AUDIO_DIN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF13_SAI1;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pin : AUDIO_RST_Pin */
  GPIO_InitStruct.Pin = AUDIO_RST_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(AUDIO_RST_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : MFX_IRQ_OUT_Pin OTG_FS_OverCurrent_Pin */
  GPIO_InitStruct.Pin = MFX_IRQ_OUT_Pin|OTG_FS_OverCurrent_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : PC0 MAG_INT_Pin MAG_DRDY_Pin */
  GPIO_InitStruct.Pin = GPIO_PIN_0|MAG_INT_Pin|MAG_DRDY_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : VLCD_Pin SEG22_Pin SEG1_Pin SEG14_Pin 
                           SEG9_Pin SEG13_Pin */
  GPIO_InitStruct.Pin = VLCD_Pin|SEG22_Pin|SEG1_Pin|SEG14_Pin 
                          |SEG9_Pin|SEG13_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : JOY_CENTER_Pin JOY_LEFT_Pin JOY_RIGHT_Pin JOY_UP_Pin 
                           JOY_DOWN_Pin */
  GPIO_InitStruct.Pin = JOY_CENTER_Pin|JOY_LEFT_Pin|JOY_RIGHT_Pin|JOY_UP_Pin 
                          |JOY_DOWN_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : MFX_WAKEUP_Pin */
  GPIO_InitStruct.Pin = MFX_WAKEUP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(MFX_WAKEUP_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG23_Pin SEG0_Pin COM0_Pin COM1_Pin 
                           COM2_Pin SEG10_Pin */
  GPIO_InitStruct.Pin = SEG23_Pin|SEG0_Pin|COM0_Pin|COM1_Pin 
                          |COM2_Pin|SEG10_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG21_Pin SEG2_Pin SEG20_Pin SEG3_Pin 
                           SEG19_Pin SEG4_Pin SEG11_Pin SEG12_Pin 
                           COM3_Pin */
  GPIO_InitStruct.Pin = SEG21_Pin|SEG2_Pin|SEG20_Pin|SEG3_Pin 
                          |SEG19_Pin|SEG4_Pin|SEG11_Pin|SEG12_Pin 
                          |COM3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : LD_R_Pin */
  GPIO_InitStruct.Pin = LD_R_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_R_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD_G_Pin */
  GPIO_InitStruct.Pin = LD_G_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(LD_G_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : AUDIO_CLK_Pin */
  GPIO_InitStruct.Pin = AUDIO_CLK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF13_SAI1;
  HAL_GPIO_Init(AUDIO_CLK_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : QSPI_CLK_Pin QSPI_CS_Pin QSPI_D0_Pin QSPI_D1_Pin 
                           QSPI_D2_Pin QSPI_D3_Pin */
  GPIO_InitStruct.Pin = QSPI_CLK_Pin|QSPI_CS_Pin|QSPI_D0_Pin|QSPI_D1_Pin 
                          |QSPI_D2_Pin|QSPI_D3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_QUADSPI;
  HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

  /*Configure GPIO pins : SEG18_Pin SEG5_Pin SEG17_Pin SEG6_Pin 
                           SEG16_Pin SEG7_Pin SEG15_Pin SEG8_Pin */
  GPIO_InitStruct.Pin = SEG18_Pin|SEG5_Pin|SEG17_Pin|SEG6_Pin 
                          |SEG16_Pin|SEG7_Pin|SEG15_Pin|SEG8_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  GPIO_InitStruct.Alternate = GPIO_AF11_LCD;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pins : OTG_FS_PowerSwitchOn_Pin OTG_FS_VBUS_Pin */
  GPIO_InitStruct.Pin = OTG_FS_PowerSwitchOn_Pin|OTG_FS_VBUS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pins : OTG_FS_DM_Pin OTG_FS_DP_Pin */
  GPIO_InitStruct.Pin = OTG_FS_DM_Pin|OTG_FS_DP_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  GPIO_InitStruct.Alternate = GPIO_AF10_OTG_FS;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : EXT_RST_Pin GYRO_INT1_Pin */
  GPIO_InitStruct.Pin = EXT_RST_Pin|GYRO_INT1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_CS_Pin */
  GPIO_InitStruct.Pin = GYRO_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GYRO_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : M3V3_REG_ON_Pin */
  GPIO_InitStruct.Pin = M3V3_REG_ON_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(M3V3_REG_ON_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GYRO_INT2_Pin */
  GPIO_InitStruct.Pin = GYRO_INT2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GYRO_INT2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_CS_Pin */
  GPIO_InitStruct.Pin = XL_CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(XL_CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : XL_INT_Pin */
  GPIO_InitStruct.Pin = XL_INT_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_EVT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(XL_INT_GPIO_Port, &GPIO_InitStruct);

}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

 /**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM1 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM1) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */
  if(htim-> Instance == TIM2){
	  gameClock++;
  }
  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */

  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
